<!DOCTYPE html>
<html>
<head>
	<title>
		Sign Up 
	</title>	
	<link rel="stylesheet" type="text/css" href="../css/log.css">
<meta charset="utf-8" name="viewport" content= "width=device-width, initial-scale=1.0"> 

</head>	
<body>
	<nav>
	<a href="../index.php"> <img src= "../img/logo.jpg" alt="logo" height="100px" width="100px" ></a>
     <ul>
					<li><a  class="active"href="../index.php">HOME</a></li>
					<li><a href="../aboutus.html">ABOUT US</a></li>
					<li><a href="../contactus.html">CONTACT US</a></li>
					<li><a href="signup.php">SIGN UP</a></li>
					<li><a href="login.php">LOG IN</a></li>

	</ul>
</nav>

<br><br>
	<br><br>
	<br><br>

<div class="signup" >
	<form action="registration.php" method="post">
	<h2>   Sign Up</h2>
    <input type="text" name="username" placeholder="First name" required /><br><br>
    <input type="text" name="lastname" placeholder="Last name" required /><br><br>
    <input type="password" name="password" placeholder="Password" required /><br><br>
    <input type="password" name="cpassword" placeholder="Confirm password" required /><br><br>
    <input type="Email" name="email" placeholder="Email id" required /><br><br>
    <button type="submit"  class="signbtn" >Signup</button><br>

<h4>Already have account?
<a href="login.php" style="text-decoration: none; font-family: 'Play', sans-serif; color: yellow;">
<br> Log In</a>	
</h4>

</form>
</div>
<br><br>
	<br><br>
	<br><br>
	<br><br>
	

<div class="footer">

			<center>
				<h3><b>©Cheers 2019 All Rights Reserved.</b></h3>
			</center>
		</div>

		</div>



</body>
</html>