<!DOCTYPE html>
<html>
<head>
	<title>
		Login page
	</title>
	<link rel="stylesheet" type="text/css" href="../css/log.css">
</head>

<style>
{
	
.btn{
  
    width: 150px;
	height: auto;
    background: white;
    color: #000;
    font-size: 16px;
    line-height: 25px;
    padding: 10px 0;
    border-radius: 25px;
    cursor: pointer;
}

}

</style>
<body>
	<nav>
	<a href="../index.php"> <img src= "../img/logo.jpg" alt="logo" height="100px" width="100px" ></a>
	            <ul>
					<li><a  class="active"href="../index.php">HOME</a></li>
					<li><a href="../aboutus.html">ABOUT US</a></li>
					<li><a href="../contactus.html">CONTACT US</a></li>
					<li><a href="signup.php">SIGN UP</a></li>
					<li><a href="login.php">LOG IN</a></li>

				</ul>
	</nav>
	<br><br>
	<br><br>
	<br><br>

	<div class="login" style="height: 300px">

	
	<form  action="validation.php" method="post" >
	<h2>Login</h2>
	<input type="text" name="username" placeholder="Username" required >
	<input type="password" name="password" placeholder="Password" required>
	<br>
	<br>
	<button type="submit" class="btn" >Login</button>
	<br>
	<br>
	<h4>Dont't have account?
	<a href="signup.php" style="text-decoration: none; color: yellow;"> <br> <br> Sign Up</a>
	</h4>
	
	</form>
	</div>
	<br><br>
	<br><br>
	<br><br>
	<br><br>
	<br>


	<div class="footer">

			<center>
				<h3><b>©Cheers 2019 All Rights Reserved.</b></h3>
			</center>
		</div>

		</div>



</body>
</html>