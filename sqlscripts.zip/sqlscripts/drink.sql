-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2019 at 09:23 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drink`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(10) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` varchar(50) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `qty` varchar(10) NOT NULL,
  `total_price` varchar(100) NOT NULL,
  `product_code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `product_name`, `product_price`, `product_image`, `qty`, `total_price`, `product_code`) VALUES
(0, 'Becherovka', '40', '../img/product_img/Becherovka.jpg', '1', '40', 'D1003');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) NOT NULL,
  `name` int(100) NOT NULL,
  `email` int(100) NOT NULL,
  `phone` int(20) NOT NULL,
  `address` int(255) NOT NULL,
  `pmode` int(50) NOT NULL,
  `products` int(255) NOT NULL,
  `amount_paid` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(10) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` varchar(50) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `product_code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `product_name`, `product_price`, `product_image`, `product_code`) VALUES
(2, 'Absinthe', '50', '../img/product_img/Absinthe.jpg', 'D1001'),
(3, 'Akvavit', '60', '../img/product_img/Akvavit.jpg', 'D1002'),
(4, 'Becherovka', '40', '../img/product_img/Becherovka.jpg', 'D1003'),
(5, 'Bourbon', '50', '../img/product_img/Bourbon.jpg', 'D1004'),
(6, 'Brennivin', '60', '../img/product_img/Brennivin1.jpg', 'D1005'),
(7, 'Caipirinha', '40', '../img/product_img/Caipirinha.jpg', 'D1006'),
(8, 'Cider', '30', '../img/product_img/Cider.jpg', 'D1007'),
(9, 'GrappaGrappa', '30', '../img/product_img/Grappa.jpg', 'D1008'),
(10, 'Jenever', '40', '../img/product_img/Jenever.jpg', 'D1009'),
(11, 'Konyagi', '70', '../img/product_img/Konyagi.jpg', 'D1010'),
(12, 'Koskenkorva', '20', '../img/product_img/Koskenkorva.jpg', 'D1011');

-- --------------------------------------------------------

--
-- Table structure for table `signtable`
--

CREATE TABLE `signtable` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signtable`
--

INSERT INTO `signtable` (`username`, `password`, `email`, `number`) VALUES
('osy', '123', 'osy@gmail.com', ''),
('Ajay', '159159159', 'ajay@gmail.com', ''),
('viraj', '123456', 'viraj.123@gmail.com', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
