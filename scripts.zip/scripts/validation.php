<?php


Session_start();


$con=mysqli_connect('localhost','root');
if($con)
{
    echo "connection done";
}
else{
    echo "not connected";
}

mysqli_select_db($con,'drink');

$username = $_POST['username'];
$password = $_POST['password'];


 $sql = "select * from signtable where username = '$username' && password ='$password'";
 
 $result = mysqli_query($con, $sql);

//  echo "$newsql";

$numcount = mysqli_num_rows($result);

if($numcount == 1)
{
    $_SESSION['name'] = $username;
    header('location:mainpage.php');
}		
else
{
    header('location:../index.php');
}






?>