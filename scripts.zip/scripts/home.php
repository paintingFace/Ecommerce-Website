
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>

<style>

*{padding:0; margin: 0; box-sizing: boredr-box}

body{
	background-image: url('../img/logbg.jpg');
	width: 100%;
	background-position: fixed;
	background-size: cover;
	background-repeat: no-repeat;
}

.welcome{
	width: 60%;
	height: auto;
	margin-top: 200px;
}

.card{
 margin-top: 15px ;}
</style>

<body>
	<nav class="navbar navbar-expand-md bg-dark navbar-dark" style="height: 70px" >
  <!-- Brand -->
  <a class="navbar-brand" href="../index.php"><img src="../img/logo.jpg" alt= logo height="110px" width="100px"  style=" border-radius:55px"></a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav ml-auto"	>

    	 <li class="nav-item">
        <a class="nav-link" href="../index.php">HOME</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="MainPage.php">PRODUCTS</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">CATEGORIES</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="checkout.php">CHECKOUT</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="cart.php"><i class="fas fa-shopping-cart"></i> <span id="cart-item" class="badge badge-danger"></span></a>
      </li>
    </ul>
  </div>
</nav>

<div class="container welcome text-center">
<div class="card cardtxt">
<div class="card-header">
<h2 class="text-center text-danger">You have Sucessfully Placed Your Order</h2>
</div>
<div class="card-body">
	<h1 class="text-info">Thank You for connecting with us...</h1>
</div>
<div class="card-footer"  >
	<a href="../index.php"><h3> <b>Logout</b>	</h3>	 </a>
</div>
</div>
<div>
</div>
</div>

</body>
</html>