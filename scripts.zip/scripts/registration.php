<?php

Session_start();
header('location:login.php');

$con=mysqli_connect('localhost','root');
if($con)
{
    echo "connection done";
}
else{
    echo "not connected";
}

mysqli_select_db($con,'drink');

$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];
$number = $_POST['number'];

 $sql = "select * from signtable where username = '$username'  && password ='$password'";

 $result = mysqli_query($con, $sql);

 echo "$newsql";

$numcount = mysqli_num_rows($result);

if($numcount == 1)
{
    echo "Duplicate data";
}
else
{
 $newsql = "INSERT INTO signtable (username, password, email, number) VALUES ('$username', '$password', '$email', '$number' )";
  mysqli_query($con,$newsql);
}

?>	