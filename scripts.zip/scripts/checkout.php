	<?php

  
require 'config.php';

$grand_total=0;
$allItems ='';
$items =array();

$sql = "SELECT CONCAT(product_name,'(',qty,')')AS ItemQty,
total_price FROM cart";
$stmt =$conn -> prepare($sql);
$stmt -> execute();

$result = $stmt ->get_result();
while ($row = $result ->fetch_assoc()) {
	$grand_total +=$row['total_price'];
	$items[] = $row['ItemQty'];
}
$allItems = implode(",", $items);
?>





<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="author" content="Cheers">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">

<title>Checkout</title>
    	<!-- Latest compiled and minified CSS -->
    			
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
		
</head>
<body>

<nav class="navbar navbar-expand-md bg-dark navbar-dark" style="height: 70px" >
  <!-- Brand -->
  <a class="navbar-brand" href="../index.php"><img src="../img/logo.jpg" alt= logo height="110px" width="100px"  style=" border-radius:55px"></a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav ml-auto"	>

    	 <li class="nav-item">
        <a class="nav-link" href="../index.php">HOME</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="MainPage.php">PRODUCTS</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">CATEGORIES</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="checkout.php">CHECKOUT</a>
      </li>
      <li class="nav-item">
       <!-- <a class="nav-link" href="cart.php"><i class="fas fa-shopping-cart"></i> <span id="cart-item" class="badge badge-danger"></span></a>-->	
      </li>
    </ul>
  </div>
</nav>
	

	<div class="container">
		<div class="row justify-content-center ">
			<div class="col-lg-6 px-4 pb-4" id="order">
				<h4 class="text-center text-info p-2"> Complete  Your Order !</h4>
				<div class="jumbotron p-3 mb-2 text-center">
					<h6 class="lead">
						<b>Product(s) : </b><?=$allItems; ?>
					</h6>
				    	<h6 class="lead">
						<b>Delivery Charge : </b>Free
					</h6>

					<h5><b>  Total Amount Payable : </b><?= number_format($grand_total,2) ?>/-</h5>
				</div>


				<form action="" method="" id="placeOrder">
				<input type="hidden" name="products" value=" <?= $allItems; ?>">
				<input type="hidden" name="products" value=" <?= $grand_total; ?>">
				<div class="form-group">
					<input type="text" name="name" class="form-control" placeholder="Enter Name" required>
				</div>
				<div class="form-group">
					<input type="email" name="email" class="form-control" placeholder="Enter E-mail Id " required>
				</div>
				<div class="form-group">
					<input type="tel" name="phone" class="form-control" placeholder="Enter phone" required>
				</div>
				<div class="form-group">	
					<textarea name="address" class="form-control" row="3" cols="10" placeholder="Enter Delivery Address Here..."></textarea>
				</div>

				<h6 class="text-center lead ">Select Payment Mode</h6>

                <div class ="form-group">
                	<select name="pmode" class="form-control">
                		<option value="COD"> Cash On Delivery </option>
                		<option value="Netbanking"> Net Banking </option>
                		<option value="Cards"> Debit / Credit card </option>
                	 </select>
                	</div>
                	<div class ="form-group">
                	<input type="button" name="submit" value="Place Order" style="background-color: #f44336; color: black; width: 400px;	margin-left: 70px;" onClick="document.location.href='./home.php'" >	

                	</div>

				</form>

				</div>
			</div>	
		</div>
	</div>





<!--Get your code at fontawesome.com-->	
<script src="https://kit.fontawesome.com/44618d7bd0.js" crossorigin="anonymous"></script>
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){	
		cart_number();

		function cart_number(){
			$.ajax({
				url: 'action.php',
				method: 'get',
				data: {cartItem:"cart_item"},
				success:function(response){
				$("#cart-item").html(response);	
				}
			})
		}
	});
</script>
</body>
</html>